@extends('admin.layouts.app')

@section('content')
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>DataTables</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">DataTables</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">

          <div class="card">
            <!-- <div class="card-header">
              <h3 class="card-title">User Managment</h3>
            </div> -->
           <!-- /.card-header -->
            <div class="card-header">
              <a class="btn btn-success" href="{{ route('users.create') }}"> New User </a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>No</th>
                <th>Name</th>
                <th>Email</th>
                <th>Roles</th>
                <th width="560px">Action</th>
                </tr>
                </thead>

                <tbody>
                  @if($data)
                  @foreach ($data as $key => $user)
                    <tr>
                      <td>{{ $key+1 }}</td>
                      <td>{{ $user->name }}</td>
                      <td>{{ $user->email }}</td>
                      <td>
                        @if(!empty($user))
                        <?php $roles = $user->getRoleNames(); ?>
                          <label class="badge badge-success">{{ $roles[0] }}</label>
                        @endif
                      </td>
                      <td>
                        <a class="btn btn-info" href="{{ route('users.show',$user->id) }}">Show</a>
                        <a class="btn btn-primary" href="{{ route('users.edit',$user->id) }}">Edit</a>
                          {!! Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']) !!}
                              {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
                          {!! Form::close() !!}
                      </td>

                    </tr>
                  @endforeach
                  @endif
                </tbody>
              </table>
              {!! $data->render() !!}
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>



<!-- Deposit Modal -->
{{-- <div class="modal fade" id="depositModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create Deposite</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <div class="modal-body">

                <form
                            role="form"
                            action="{{route('admin.wallet.store')}}"
                            method="post"
                            class="require-validation"
                            data-cc-on-file="false"
                            data-stripe-publishable-key="{{ env('STRIPE_KEY') }}"
                            id="payment-form">
                        @csrf

                        <input type="hidden" name="user_id" id="deposit">
                        <div class='form-row row'>
                            <div class='col-md-6 form-group required'>
                                    <label>Deposite Amount</label>
                                    <input type="text" name="dep_amount" class="form-control" placeholder="Deposite Amount">
                                    @if ($errors->has('dep_amount'))
                                        <span class="text-danger">{{ $errors->first('dep_amount') }}</span>
                                    @endif
                              </div>
                              <div class='col-md-6 form-group required'>
                                <label class='control-label'>Name on Card</label> <input
                                    class='form-control' size='4' type='text'>
                            </div>
                        </div>



                        <div class='form-row row'>
                            <div class='col-md-12 form-group card required'>
                                <label class='control-label'>Card Number</label> <input
                                    autocomplete='off' class='form-control card-number' size='20'
                                    type='text'>
                            </div>
                        </div>

                        <div class='form-row row'>
                            <div class='col-xs-12 col-md-4 form-group cvc required'>
                                <label class='control-label'>CVC</label> <input autocomplete='off'
                                    class='form-control card-cvc' placeholder='ex. 311' size='4'
                                    type='text'>
                            </div>
                            <div class='col-xs-12 col-md-4 form-group expiration required'>
                                <label class='control-label'>Expiration Month</label> <input
                                    class='form-control card-expiry-month' placeholder='MM' size='2'
                                    type='text'>
                            </div>
                            <div class='col-xs-12 col-md-4 form-group expiration required'>
                                <label class='control-label'>Expiration Year</label> <input
                                    class='form-control card-expiry-year' placeholder='YYYY' size='4'
                                    type='text'>
                            </div>
                        </div>

                        <div class='form-row row'>
                            <div class='col-md-12 error form-group hide'>
                                <div class='alert-danger alert'>Please correct the errors and try
                                    again.</div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-12">
                                <button class="btn btn-primary btn-lg btn-block" type="submit">Pay Now</button>
                            </div>
                        </div>

                    </form>


                </div>
    </div>
  </div>
</div>
<!-- End Deposit -->

<!-- withdraw Modal -->
<div class="modal fade" id="withdrawModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Create Withdraw</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <i aria-hidden="true" class="ki ki-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" class="require-validation" action="{{route('admin.wallet.create.withdraw')}}" style="margin-left: 15px ; margin-right: 15px">
                        {{ csrf_field() }}
                        <input type="hidden" name="user_id" id="withdraw">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Withdraw</label>
                                    <input type="text" name="drw_amount" class="form-control" placeholder="200">
                                    @if ($errors->has('drw_amount'))
                                        <span class="text-danger">{{ $errors->first('drw_amount') }}</span>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-light-primary font-weight-bold" data-dismiss="modal">CLOSE</button>
                            <button type="submit" class="btn btn-primary font-weight-bold">SAVE</button>
                            <button type="reset" class="btn btn-primary font-weight-bold">RESET</button>
                        </div>
                    </form>
                </div>
    </div>
  </div>
</div> --}}
<!-- End withdraw -->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script type="text/javascript">
// $(function() {
//   var $form = $(".require-validation");
//   $('form.require-validation').bind('submit', function(e) {
//     var $form = $(".require-validation"),
//     inputSelector = ['input[type=email]', 'input[type=password]', 'input[type=text]', 'input[type=file]', 'textarea'].join(', '),
//     $inputs = $form.find('.required').find(inputSelector),
//     $errorMessage = $form.find('div.error'),
//     valid = true;
//     $errorMessage.addClass('hide');
//     $('.has-error').removeClass('has-error');
//     $inputs.each(function(i, el) {
//         var $input = $(el);
//         if ($input.val() === '') {
//             $input.parent().addClass('has-error');
//             $errorMessage.removeClass('hide');
//             e.preventDefault();
//         }
//     });
//     if (!$form.data('cc-on-file')) {
//       e.preventDefault();
//       Stripe.setPublishableKey($form.data('stripe-publishable-key'));
//       Stripe.createToken({
//           number: $('.card-number').val(),
//           cvc: $('.card-cvc').val(),
//           exp_month: $('.card-expiry-month').val(),
//           exp_year: $('.card-expiry-year').val()
//       }, stripeResponseHandler);
//     }
//   });

//   function stripeResponseHandler(status, response) {
//       if (response.error) {
//           $('.error')
//               .removeClass('hide')
//               .find('.alert')
//               .text(response.error.message);
//       } else {
//           /* token contains id, last4, and card type */
//           var token = response['id'];
//           $form.find('input[type=text]').empty();
//           $form.append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
//           $form.get(0).submit();
//       }
//   }
// });
</script>

@endsection




